#!/usr/bin/env python3
"""Deterministic module envelope: manifest.json followed by payload.tar.gz."""
import argparse,hashlib,json,os,tarfile,gzip,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('kind',choices=['runtime','core','webui','bridge']);p.add_argument('source');p.add_argument('output');p.add_argument('--version');a=p.parse_args()
versions=json.loads((Path(__file__).parent/'versions.json').read_text());version=a.version or versions[a.kind]
root=Path(a.source).resolve();out=Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
files=[]
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
with tempfile.TemporaryDirectory(dir=out.parent) as tmp:
    payload=Path(tmp)/'payload.tar.gz'
    with payload.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',compresslevel=1,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for item in sorted(root.rglob('*')):
            rel=item.relative_to(root).as_posix();info=tar.gettarinfo(str(item),rel);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            if info.isreg():
                # Exported runtime hardlinks are intentionally materialized. Each file has its own verified hash.
                info.type=tarfile.REGTYPE;info.size=item.stat().st_size
                record={'path':rel,'type':'file','size':info.size,'mode':info.mode&0o777,'sha256':digest(item)}
                with item.open('rb') as stream:tar.addfile(info,stream)
            elif info.isdir():record={'path':rel,'type':'dir','mode':info.mode&0o777};tar.addfile(info)
            elif info.issym():record={'path':rel,'type':'symlink','link':info.linkname,'mode':0o777};tar.addfile(info)
            elif info.islnk():
                info.type=tarfile.REGTYPE;info.linkname='';info.size=item.stat().st_size
                record={'path':rel,'type':'file','size':info.size,'mode':info.mode&0o777,'sha256':digest(item)}
                with item.open('rb') as stream:tar.addfile(info,stream)
            else:continue
            files.append(record)
    bootstrap_min=('1.2.7' if ((a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,13,4)) or
                              (a.kind=='bridge' and tuple(map(int,version.split('.'))) >= (5,3))) else
                   ('1.2.6' if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,13,3) else
                   ('1.2.5' if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,13,2) else
                   ('1.2.4' if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,12,11) else
                   ('1.2.3' if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,12,2) else
                   ('1.1.0' if a.kind in ('core','webui','bridge') else '1.0.0'))))))
    requires={'bootstrap':{'min':bootstrap_min,'max':'1.99.99'}}
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,18,0):
        requires['bootstrap']['min']='1.2.10'
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,18,14):
        requires['bootstrap']['min']='1.2.15'
    if a.kind=='webui' and tuple(map(int,version.split('.'))) >= (4,7,3):
        requires['bootstrap']['min']='1.2.11'
    if a.kind!='runtime':requires['runtime']={'min':'1.0.0','max':'1.99.99'}
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,15,0):
        requires['runtime']['min']='1.0.1'
    if a.kind in ('webui','bridge'):requires['core']={'min':versions['core'],'max':'3.99.99'}
    # Compatibility release: profile navigation uses the existing status
    # schema. Core 3.18.2 ignores scope=profile; immediate rendering and stale
    # response protection still work. New parser features remain capability-
    # checked by the UI rather than being enabled on an older Core.
    if a.kind=='webui' and version=='4.7.6':requires['core']['min']='3.18.2'
    # The report download UI works with Core 3.18.40; the newer J-Crypto
    # strategy remains capability-gated until Core 3.18.41 is installed.
    if a.kind=='webui' and version=='4.7.66':requires['core']['min']='3.18.40'
    multi_profile_migration=a.kind=='core' and version=='3.10.0'
    application_profile_migration=a.kind=='core' and version=='3.12.0'
    workflow_schema=a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,11,0)
    full_net_be_migration=a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,13,0)
    migration_schema=('v14-full-net-be-symbol-spec-cache' if full_net_be_migration else
                      ('v13-application-profile-settings' if application_profile_migration else
                      ('v12-parser-workflow' if workflow_schema else
                       ('v11-trading-profiles' if multi_profile_migration else 'none'))))
    migration_description=('Persist exact account/symbol passports, complete commission tariffs, tariff hashes, confirmed overrides and full-net BE command/binding policy while retaining all profiles and campaigns.'
                           if full_net_be_migration else
                           ('Separate global Telegram/Parser/MT5 infrastructure from Application Profiles and create an isolated execution database per MT5 binding while retaining credentials and installations.'
                           if application_profile_migration else
                           ('Create profile-scoped workflow.sqlite lazily and migrate custom parser rules to schemaVersion 2 while retaining legacy semantics.'
                            if workflow_schema else
                            ('Migrate the stopped single-profile NAS state into an isolated Default Profile.'
                             if multi_profile_migration else 'No persistent schema change.'))))
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,14,0):
        migration_schema='v15-telegram-reply-campaign-risk'
        migration_description='Add native Telegram reply metadata, indexed persistent message-to-campaign identities and stable leg roles; retain existing profiles, data and full-net BE policy.'
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,15,0):
        migration_description+=' Add optional stable forum-topic routing and cached topic names to profile JSON; enforce topic boundaries before parsing and campaign management.'
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,18,0):
        migration_schema='nas-audit-v1'
        migration_description='Add reporting/events.sqlite append-only journal, transactional audit outboxes/triggers in existing binding databases and reporting settings. Add source IDs to workflow_reports. Existing trading state/rules retained; audit and reports retained on rollback. Requires Bootstrap Public bind mount; Bridge 5.10 adds deal/request telemetry.'
    if a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,18,17):
        migration_description='Добавляются неизменяемые сжатые объекты настроек audit_objects и поля повторов failures/retry_after в reporting/events.sqlite. Старые события и торговые базы сохраняются. Новые архивы GTM_COMPACT_V2 содержат все объекты и автономный скрипт восстановления JSONL. Для чтения новых объектов журнала нужен Core 3.18.17+. Откат сохраняет данные и торговые настройки; новый формат отчётов требует совместимого читателя.'
    manifest={'format':1,'type':a.kind,'version':version,'architecture':'x86_64','requires':requires,
        'bridge_protocol':versions['bridge_protocol'],'payload_sha256':digest(payload),'payload_bytes':payload.stat().st_size,
        'expanded_bytes':sum(x.get('size',0) for x in files),'files':files,
        'migration':{'schema':migration_schema,'required':multi_profile_migration or application_profile_migration or full_net_be_migration,'reversible':True,
                     'description':migration_description},
        # Core activation replaces the private namespace, including its MT5s.
        'restart':{'core':a.kind in ('runtime','core','bridge'),'mt5':a.kind in ('runtime','bridge') or (a.kind=='core' and tuple(map(int,version.split('.'))) >= (3,18,14))},
        'bridge_version':versions['bridge'] if a.kind=='bridge' else ''}
    blob=json.dumps(manifest,separators=(',',':'),sort_keys=True).encode()
    with tarfile.open(out,'w',format=tarfile.USTAR_FORMAT) as tar:
        import io
        info=tarfile.TarInfo('manifest.json');info.size=len(blob);info.mode=0o644;tar.addfile(info,io.BytesIO(blob))
        info=tarfile.TarInfo('payload.tar.gz');info.size=payload.stat().st_size;info.mode=0o644
        with payload.open('rb') as stream:tar.addfile(info,stream)
    out.with_name(out.name+'.sha256').write_text(digest(out)+'  '+out.name+'\n')
    print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'payload_bytes':manifest['payload_bytes'],'files':len(files)}))
